import React from "react";
import '../App'; 


const Footer = () => {
  return (
    <div className="footer">
      <p>Books App 2022&copy;</p>
    </div>
  );
};

export default Footer;
